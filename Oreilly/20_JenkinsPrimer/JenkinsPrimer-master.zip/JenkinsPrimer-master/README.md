# This repo is for my Jenkins Primer course

Some example configurations and commands are included here .. they are explained during the course